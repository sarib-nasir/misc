"use strict";
//logs
const get_logs = require("./logs/get_items.js");
const add_logs = require("./logs/add_item.js");
const update_logs = require("./logs/update_item.js");
const delete_logs = require("./logs/delete_item.js");



exports.handler =  async (event, context, callback) => {

//Get Item:Default
if(event.httpMethod=="GET"){
   
   if(event.pathParameters && event.pathParameters.log_id){
         await get_logs.get_item(event, context, callback);
   }else{
         await get_logs.get_items(event, context, callback);
   }
}     
     
//Add Item:Default
if(event.httpMethod=="POST"){
   await add_logs.add_item(event, context, callback);
}

//Update Item:Default
if(event.httpMethod=="PUT"){
   await update_logs.update_item(event, context, callback);
}
  
//Delete:Default
if(event.httpMethod=="DELETE"){
   await delete_logs.delete_item(event, context, callback);
}



};