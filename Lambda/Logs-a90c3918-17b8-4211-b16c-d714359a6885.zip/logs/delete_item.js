var ObjectId = require('mongodb').ObjectID;

var config =  require ('../config.js');

module.exports = {

//======================================================================
// Delete Item
//======================================================================

delete_item : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  
   //Path Parameters (wheatpaste.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (wheatpaste.com?title='sdad')
  //JSON (queryStringParam.title)
  const queryStringParam = event.queryStringParameters;  
  
  //GET Data
  var log_id = pathParam.log_id; 
  
  console.log(log_id)
  await config.connectToDatabase()
    .then(db => config.delete_doc(db,log_id))
    .then(result => {
      console.log("delete result here")
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
   


 
    
}