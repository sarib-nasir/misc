var config =  require ('../config.js');
const AWS = require("aws-sdk");
var s3 = new AWS.S3();

module.exports = {

//======================================================================
// Add  (Give Access Administrator Lambda Role to upload image)
//======================================================================

add_item : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  //Path Parameters (wheatpaste.com/accountID/)
  //JSON (pathParam.accountID)
  //const pathParam = event.pathParameters;
  
  //Query String Parameters (wheatpaste.com?name='sdad')
  //JSON (queryStringParam.name)
  const queryStringParam = event.queryStringParameters;  
  
  //GET Data
  var body =  JSON.parse(event.body);  
  var myobj = { 
        name : body.name,
        created_at: new Date(),
        updated_at: new Date(),

    
  };
  
    //Insert Data in Database
   await config.connectToDatabase()
    .then(db => config.insert_doc(db,myobj))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
}
   


 
    
};