'use strict';
const signInUser= require("./auth/Sign-In/SignIn.js");
const signUpUser= require("./auth/Sign-Up/SignUp.js");
const confirmSignUp= require("./auth/Sign-Up/confirmUser.js");
const signOutUser= require("./auth/Sign-Out/SignOut.js");
const forgotPassword = require("./auth/Sign-In/ForgotPassword.js");
const getCode = require("./auth/Sign-In/ConfirmationCode.js");
const deleteUser = require("./auth/Delete/Delete.js");
const getUser = require("./auth/Get/Get.js");
const addUser = require("./auth/Add/Add.js");
const token= require("./auth/Sign-In/refreshToken.js");
const profile = require("./auth/profile/Profile.js");


exports.handler = (event, context, callback) => {
  
  console.log(event)
  
  // user login handler 
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/signin"){
    signInUser.signIn(event,context,callback);
  }
  // user signUp handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/signup"){
    signUpUser.signUp(event,context,callback);
  }
  // change password handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/confirm"){
    confirmSignUp.confirmUser(event,context,callback);
  }
  // forgot password code generator handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/signout"){
    signOutUser.signOut(event,context,callback);
  }
  // forgot password code generator handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/reset"){
    forgotPassword.forgotPass(event,context,callback); 
  }
  // change password handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/refresh"){
    token.refreshToken(event,context,callback);
  }
  // change password handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/recovery"){
    getCode.resetPass(event,context,callback);
  }
  
  // change password handler
  if(event.httpMethod=="DELETE" && event.resource== "/v1/auth/delete/{accountID}/{userID}/{uid}"){
    deleteUser.delete_user_account(event,context,callback);
  }
  // change password handler
  if(event.httpMethod=="GET" && event.resource== "/v1/auth/get/{accountID}"){
    getUser.get_user_accounts_by_account_id(event,context,callback);
  }
  // change password handler
  if(event.httpMethod=="POST" && event.resource== "/v1/auth/add"){
    addUser.add_user_account(event,context,callback);
  }
  // change password handler
  if(event.resource== "/v1/auth/profile/{profileID}"){
    if(event.httpMethod=="PUT"){
      profile.update_profile(event,context,callback);
    }else{
      profile.get_profile(event,context,callback);
    
    }
  }


  
  
  if (event.triggerSource === "CustomMessage_ForgotPassword") {
    var CustomMessage_ForgotPassword = `
    <style>
      p {display: block;font-size: 14px;margin-block-start: 1em;margin-block-end: 1em;margin-inline-start: 0px;margin-inline-end: 0px;}
    </style>
    <div>
      <p>
      <img align="center"
        alt="logo"
        src=""
        width="248"
        style="max-width:400px;padding-bottom:0px;vertical-align:bottom;display:inline!important;border:1px none;border-radius:0%;height:auto;outline:none;text-decoration:none"
      >
      <br/>
      <br/>
      <p style="font-size=28px;font-weight:bold;">You have submitted a password change request</p>
      <p>If this was you click the URL below to change your password</p>
      <p><a href="http://localhost:3000/reset-password?confirmation_code=${event.request.codeParameter}&username=${event.userName}"> Reset Password </a></p>
    </div>`;
    event.response.emailMessage = CustomMessage_ForgotPassword;
    callback(null, event);
  }
  
  
  
   if (event.triggerSource === "CustomMessage_SignUp") {
    var CustomMessage_SignUp = `
    <style>
      p {display: block;font-size: 14px;margin-block-start: 1em;margin-block-end: 1em;margin-inline-start: 0px;margin-inline-end: 0px;}
    </style>
    <div>
      <p>
      <img align="center"
        alt="logo"
        src=""
        width="248"
        style="max-width:400px;padding-bottom:0px;vertical-align:bottom;display:inline!important;border:1px none;border-radius:0%;height:auto;outline:none;text-decoration:none"
      >
      <br/>
      <br/>
      <p style="font-size=28px;font-weight:bold;">confirm your registration</p>
      <p>If this was you click the URL below to change your password</p>
      <p>confirmation_code=${event.request.codeParameter}&username=${event.userName} </p>
      <p><a href="http://localhost:3000/confirm?confirmation_code=${event.request.codeParameter}&username=${event.userName}"> Confirm Email Address </a></p>
    </div>`;
    event.response.emailMessage = CustomMessage_SignUp;
    callback(null, event);
  }
  
                

};
