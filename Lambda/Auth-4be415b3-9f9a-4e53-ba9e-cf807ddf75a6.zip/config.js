const MongoClient = require('mongodb').MongoClient;
var ObjectId = require('mongodb').ObjectID;

/**
* This file is use to handle all the functions
* in your development cycle save you a lot of time by preventing you having to rewrite<br>
* major documentation parts to generate some usable form of documentation.
*/
module.exports = {

//======================================================================
// MongoDB Auth Url with username, pasword and database
//======================================================================
  mongo_url: function() {
    return "mongodb+srv://uni:R5EdNcNClh3Tv1sO@uni.gvzzp.mongodb.net/uni?retryWrites=true&w=majority";
  },
  
//======================================================================
// Database Name
//======================================================================
  dbname: function() {
    return "uni";
  },
  
//======================================================================
// Collection  Name
//======================================================================
  collection_name: function() {
    return "users";
  },
//======================================================================
// AWS Region
//======================================================================
  region: function() {
    return "ws-west-2";
  },
//======================================================================
// S3 Bucket Name
//======================================================================
  bucket_name: function() {
    return "wheatpaste-production";
  },
//======================================================================
// S3 Bucket URL
//======================================================================
  bucket_url: function(uid) {
    return "media-archive/media-library/" + uid;
  },
//======================================================================
// MongoDB Database Function
//======================================================================
  connectToDatabase: function() {
    return MongoClient.connect(this.mongo_url(), {
      useNewUrlParser: true,
      useUnifiedTopology: true
    }).then(client => {
      // The database name is part of the url.  client.db() seems 
      // to know that and works even without a parameter that 
      // relays the db name.
      let db = client.db(this.dbname());
      return db;
      // client.close() if you want to
    }).catch(err => console.log(err));
  },
//======================================================================
// Insert Data
//======================================================================
  insert_doc: function(db, items_bucket) {
    console.log('=> query database');
    return db.collection(this.collection_name()).insertOne(items_bucket).then((items) => {
      //console.log(items);
      return {
        "statusCode": 200,
        "body":items.ops[0],
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
//======================================================================
// Update Data
//======================================================================
  update_doc: function(db, id, items_bucket) {
    console.log('=> update query database');
    return db.collection(this.collection_name()).findOneAndUpdate({
      _id: ObjectId(id)
    }, {
      $set: items_bucket
    }, {returnOriginal: false, upsert: true}).then((items) => {
      return {
        "statusCode": 200,
        "body": JSON.stringify(items.value),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
//======================================================================
// Get Item
//======================================================================
  get_item: function(db, user_id) {
    return db.collection(this.collection_name()).findOne({
      "user_id": user_id
    }).then((items) => {
      return {
        "statusCode": 200,
        "body": items,
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
  //======================================================================
// Insert Data
//======================================================================
  insert_user_account: function(db, items_bucket) {
    console.log('=> query database');
    return db.collection("wp_user_accounts").insertOne(items_bucket).then((items) => {
      //console.log(items);
      return {
        "statusCode": 200,
        "body":items.ops[0],
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
  //======================================================================
// Delete Data
//======================================================================
  delete_user_account: function(db, params) {
    console.log('=> query database');
    return db.collection("wp_user_accounts").deleteOne(params).then((items) => {
      return {
        "statusCode": 200,
        "body": true,
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
    //======================================================================
// Get All List with Pagination
//======================================================================
    get_user_accounts_by_account_id : function (db,account_id,title,page,per_page,account_type,sort) {
    
    const is_account_type = ((account_type)?{$eq :account_type}: {$regex : ".*.*"});
    

    return db.collection("wp_user_accounts").aggregate([
  {
    $facet: {
      metadatax: [
        {
          $match: {
            account_id: {$eq :account_id},
          }
          
        },
        {
           $sort: sort
           
         },     
        {
          $count: "total_records",
          
        }
      ],
      metadata: [
        {
          $match: {
            account_id: {$eq :account_id},
          }
          
        },
         {
           $sort: sort
           
         },
        {
          $skip: page * per_page
        },
        {
          $limit: per_page
        },
        {
        $lookup: {
                  from: "wp_users",
                  let: {
                    user_id: "$user_id",
                  },
                  pipeline: [
                    {
                      $match: {
                        $expr: {
                          $or: [
                            {
                                      
                              $and: [
                                {
                                  $eq: ["$user_id", "$$user_id"],
                                },
                                
                              ],                                
                            },
                          ],
                        },
                      },
                    },
                  ],
                  as: "user_data",
                },
              },
              {
                $unwind: {
                  path: "$user_data",
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $skip: page * per_page,
              },
              {
                $limit: per_page,
              },
              {
                $group: {
                  _id: null,
                  count: {
                    $sum: 1,
                  },
                  data: {
                    $push: "$$ROOT",
                  },
                },
              },
      ]
    }
  },
  {
    $unwind: "$metadata"
  },
  {
    $project: {
      data: "$metadata.data",
      metadata: {
        $mergeObjects: [
          {
            per_page: "$metadata.count",
            total_pages: { $ceil: { $divide: [ { $arrayElemAt: [ "$metadatax.total_records",  0 ] } , per_page ] } } 
          },
          {
            $arrayElemAt: [
              "$metadatax",
              0
            ]
          },
          
        ]
      }
    }
  }
]).toArray()
    .then((items) => {       
      return {
        "statusCode": 200,
        "body": JSON.stringify(items[0]),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      }; 
      
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });


},

//======================================================================
// Update Data
//======================================================================
  update_profile: function(db, profileID, items_bucket) {
    console.log('=> update query database');
    return db.collection("users").findOneAndUpdate({
      "user_id": profileID
    }, {
      $set: items_bucket
    }, {returnOriginal: false, upsert: true}).then((items) => {
      return {
        "statusCode": 200,
        "body": JSON.stringify(items.value),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
//======================================================================
// Get Item
//======================================================================
  get_profile: function(db, profileID) {
    return db.collection("users").findOne({
      "user_id": profileID,
      //"uid": uid
    }).then((items) => {
      return {
        "statusCode": 200,
        "body": JSON.stringify(items),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },   
};