var config =  require ('../../config.js');

module.exports = {

//======================================================================
// Add  (Give Access Administrator Lambda Role to upload image)
//======================================================================

add_user_account : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  //Path Parameters (ab.com/accountID/)
  //JSON (pathParam.accountID)
  //const pathParam = event.pathParameters;
  
  //Query String Parameters (ab.com?title='sdad')
  //JSON (queryStringParam.title)
  //const queryStringParam = event.queryStringParameters;  
  
  //GET Data
  var body =  JSON.parse(event.body);  
  
  

  
              var myobj = {
                    user_id : null,
                    email: body.email,
                    account_id : body.account_id,
                    roles : body.roles,
                    invite_status:0,
                    created_at: new Date(),
                    updated_at: new Date(),
            
                
              };
              
              console.log(myobj)
                //Insert Data in Database
               await config.connectToDatabase()
                .then(db => config.insert_user_account(db,myobj))
                .then(result => {
                  console.log(result);
                  
                  
                callback(null, { 
                statusCode: 200,                
                headers: {
                  "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
                  'Content-Type': 'application/json',
                }, 
                body:JSON.stringify(result.body) 
                  });
            });
                  
}
   


 
    
};