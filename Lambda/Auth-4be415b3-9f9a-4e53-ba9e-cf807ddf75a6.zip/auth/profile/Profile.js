const MongoClient = require('mongodb').MongoClient;
var config =  require ('../../config.js');
var ObjectId = require('mongodb').ObjectID;

module.exports = {
//======================================================================
// Update Item
//======================================================================

update_profile : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;

  //Path Parameters (ab.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (ab.com?name='sdad')
  //JSON (queryStringParam.name)
  const queryStringParam = event.queryStringParameters;
  
  //GET Data
  var body = JSON.parse(event.body);

  var profileID =  pathParam.profileID;
  var items_bucket =  {
        first_name : body.first_name,
        last_name : body.last_name,
        phone : body.phone,
        updated_at: new Date(),
    
  };
  
  await config.connectToDatabase()
    .then(db => config.update_profile(db,profileID,items_bucket))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
//======================================================================
// GET Single Item
//======================================================================
get_profile : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;

  //Path Parameters (ab.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (ab.com?name='sdad'&per_page=10&page=1&page=1&sort=ASC)
  //JSON (queryStringParam.name)
  //const queryStringParam = event.queryStringParameters;
  //GET Data
 // var body = JSON.parse(event.body);    
  
  var profileID = pathParam.profileID;

  await config.connectToDatabase()
    .then(db => config.get_profile(db,profileID))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},

 
    
}