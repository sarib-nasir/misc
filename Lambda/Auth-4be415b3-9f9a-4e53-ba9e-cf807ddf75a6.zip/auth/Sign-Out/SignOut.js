var AmazonCognitoIdentity = require('amazon-cognito-identity-js');
module.exports = {
  signOut: async function (data, context, callback) {  
  // cognito user pool
    const poolData={
      UserPoolId: 'eu-west-2_W4Gdcok54', // Your user pool id here
      ClientId: '54klbd89520q5j68fe8hefml1f', // Your client id here
    };
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    
    const user = userPool.getCurrentUser();
    if (user) {
      user.signOut(); // signOut user 
    }
  }
}