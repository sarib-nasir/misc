var AmazonCognitoIdentity = require('amazon-cognito-identity-js');

module.exports = {
    confirmUser : async function (event, context, callback){
        context.callbackWaitsForEmptyEventLoop = false;
        
        
          //Path Parameters (ab.com/accountID/)
          //JSON (pathParam.accountID)
          //const pathParam = event.pathParameters;
          
          //Query String Parameters (ab.com?title='sdad')
          //JSON (queryStringParam.title)
          //const queryStringParam = event.queryStringParameters;  
          
          //GET Data
          var body =  JSON.parse(event.body);  
          console.log(event.body)
  
    // const poolData={
    //   UserPoolId: 'eu-west-2_ppL2c6LcM', // Your user pool id here
    //   ClientId: '593heon7rbemm2i6buld6r30bc', // Your client id here
    // };
        const poolData={
      UserPoolId: 'eu-west-2_W4Gdcok54', // Your user pool id here
      ClientId: '54klbd89520q5j68fe8hefml1f', // Your client id here
    };
        var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
        const getUser=()=>{
            return new AmazonCognitoIdentity.CognitoUser({
                Username:body.email,
                Pool:userPool
            });
        };
        // generates code for reset password
        getUser().confirmRegistration(body.code, true, function(err, result) {
        
        if(err) {
                callback(null,{
                    "statusCode": 500,
                    "body": JSON.stringify(err),
                    "headers": {
                        "Access-Control-Allow-Origin": "*"
                      }
                });
            } else {
                callback(null,{ 
                statusCode: 200,                
                headers: {
                  "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
                  'Content-Type': 'application/json',
                }, 
                body:JSON.stringify(result) 
              });
            }
        });
    }
}