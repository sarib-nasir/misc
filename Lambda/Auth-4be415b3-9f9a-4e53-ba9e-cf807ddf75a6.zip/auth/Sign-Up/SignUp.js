var AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const config =  require ('../../config.js');

module.exports = {

    signUp : async function (event, context, callback){
        context.callbackWaitsForEmptyEventLoop = false;

    //Path Parameters (ab.com/accountID/)
      //JSON (pathParam.accountID)
      //const pathParam = event.pathParameters;
      
      //Query String Parameters (ab.com?title='sdad')
      //JSON (queryStringParam.title)
      //const queryStringParam = event.queryStringParameters;  
      
      //GET Data
      var body =  JSON.parse(event.body);      

        // cognito user pool
    // const poolData={
    //   UserPoolId: 'eu-west-2_ppL2c6LcM', // Your user pool id here
    //   ClientId: '593heon7rbemm2i6buld6r30bc', // Your client id here
    // };
        const poolData={
      UserPoolId: 'eu-west-2_W4Gdcok54', // Your user pool id here
      ClientId: '54klbd89520q5j68fe8hefml1f', // Your client id here
    };
        var userPool =new AmazonCognitoIdentity.CognitoUserPool(poolData);
        var attributeList = [];
        
        var dataPhoneNumber = {
        	Name: 'phone_number',
        	Value: body.phone_number,
        };
        var attributePhoneNumber = new AmazonCognitoIdentity.CognitoUserAttribute(
        	dataPhoneNumber
        );
        
        attributeList.push(attributePhoneNumber);

        
        // creating new user via AWS Cognito
        userPool.signUp(body.email,body.password, attributeList, null,async function(err, cognito_data) {
            if(err) {
               
                callback(null,{
                    "statusCode": 500,
                    "body": JSON.stringify(err),
                    "headers": {
                        "Access-Control-Allow-Origin": "*"
                      }
                });
            } else {
            
            var user = cognito_data.user;    

                callback(null,{
                    "statusCode": 200,
                    "body": JSON.stringify(user),
                    "headers": {
                        "Access-Control-Allow-Origin": "*"
                      }
                });
                
                
    //         var user_data = {
    //             user_id: cognito_data.userSub,
    //             account_type: body.account_type,
    //             first_name: '',
    //             last_name: '',
    //             profile_pic:null,
    //             email: user.username,
    //             phone: '',
    //             created_at: new Date(),
    //             updated_at: new Date(),                
    //         }
            
    // //insert into users        
    // await config.connectToDatabase()
    //         .then(db => config.insert_doc(db,user_data))
    //         .then(result => {
                
                
    //             callback(null, { 
    //             statusCode: 200,                
    //             headers: {
    //               "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
    //               'Content-Type': 'application/json',
    //             }, 
    //             body:JSON.stringify(result.body) 
    //               });
                                  
            
              
    //         })
    //         .catch(err => {
    //           console.log('=> an error occurred: ', err);
    //                   callback(null,{
    //             "statusCode": 500,
    //             "body": JSON.stringify(err),
    //             "headers": {
    //                 "Access-Control-Allow-Origin": "*"
    //               }
    //             });
    //         });               
                
                
                
                
                
            }
        });
        
    }
    
}