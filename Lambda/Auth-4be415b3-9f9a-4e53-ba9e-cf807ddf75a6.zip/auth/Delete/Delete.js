var ObjectId = require('mongodb').ObjectID;

var config =  require ('../../config.js');

module.exports = {

//======================================================================
// Delete Item
//======================================================================

delete_user_account : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  
   //Path Parameters (ab.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (ab.com?title='sdad')
  //JSON (queryStringParam.title)
  //const queryStringParam = event.queryStringParameters;  
  
  //GET Data
  //var body = JSON.parse(event.body);   

  var myobj = ({ _id: ObjectId(pathParam.uid), account_id:  pathParam.accountID, user_id:  pathParam.userID});

  await config.connectToDatabase()
    .then(db => config.delete_user_account(db,myobj))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
   
}