var AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const config =  require ('../../config.js');

module.exports = {

  refreshToken : async function (event, context, callback){
    context.callbackWaitsForEmptyEventLoop = false;
    
  
  //Path Parameters (ab.com/accountID/)
  //JSON (pathParam.accountID)
  //const pathParam = event.pathParameters;
  
  //Query String Parameters (ab.com?title='sdad')
  //JSON (queryStringParam.title)
  //const queryStringParam = event.queryStringParameters;  
  
  //GET Data
  var body =  JSON.parse(event.body);   
  
  var token = new AmazonCognitoIdentity.CognitoRefreshToken({ RefreshToken: body.refreshToken });
  
     // firstPool data
    const poolData={
      UserPoolId: 'eu-west-2_W4Gdcok54', // Your user pool id here
      ClientId: '54klbd89520q5j68fe8hefml1f', // Your client id here
    };
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    
    
    var userData = {
        Username: body.email,
        Pool: userPool,
    };
    const user = new AmazonCognitoIdentity.CognitoUser(userData);
   
    user.refreshSession(token, async function (err, cognito_data) {
        
        if(err) {
                callback(null,{
                    "statusCode": 500,
                    "body": JSON.stringify(err),
                    "headers": {
                        "Access-Control-Allow-Origin": "*"
                      }
                });
            } else {
                

       var user_id = cognito_data.idToken.payload.sub;
          callback(null, { 
            statusCode: 200,                
            headers: {
              "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
              'Content-Type': 'application/json',
            }, 
            body:JSON.stringify(cognito_data) 
          });
          // await config.connectToDatabase()
          //   .then(db => config.get_item(db,user_id))
          //   .then(result => {
          //     var user_data = result.body;
              
          //     var data = {
          //       user_id: user_id,
          //       account_type: ((user_data && user_data.account_type)?user_data.account_type:null),
          //       first_name: ((user_data && user_data.first_name)?user_data.first_name:null) ,
          //       last_name: ((user_data && user_data.last_name)?user_data.last_name:null) ,
          //       profile_pic: ((user_data && user_data.profile_pic)?user_data.profile_pic:null) ,
          //       email: cognito_data.idToken.payload.email,
          //       email_verified: cognito_data.idToken.payload.email_verified,
          //       phone: cognito_data.idToken.payload.phone_number,
          //       jwtToken:  cognito_data.idToken.jwtToken,
          //       refreshToken:  cognito_data.refreshToken.token,
          //       created_at: result.body.created_at,
          //       updated_at: result.body.updated_at,
          //     };
              
              
          // // login user in the cognito user account
          // callback(null, { 
          //   statusCode: 200,                
          //   headers: {
          //     "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
          //     'Content-Type': 'application/json',
          //   }, 
          //   body:JSON.stringify(data) 
          // });
              
          //   })
          //   .catch(err => {
          //     console.log('=> an error occurred: ', err);
          //             callback(null,{
          //       "statusCode": 500,
          //       "body": JSON.stringify(err),
          //       "headers": {
          //           "Access-Control-Allow-Origin": "*"
          //         }
          //       });
          //   });
            }
            
        // console.log(err, session);
    });
  
  
  }
  
}