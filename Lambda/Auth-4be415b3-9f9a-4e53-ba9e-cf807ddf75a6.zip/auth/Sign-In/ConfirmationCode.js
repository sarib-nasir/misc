var AmazonCognitoIdentity = require('amazon-cognito-identity-js');

module.exports = { 

    resetPass : async function (event, context, callback){
        context.callbackWaitsForEmptyEventLoop = false;
        
        //Path Parameters (ab.com/accountID/)
        //JSON (pathParam.accountID)
        //const pathParam = event.pathParameters;
        
        //Query String Parameters (ab.com?title='sdad')
        //JSON (queryStringParam.title)
        //const queryStringParam = event.queryStringParameters;  
        
        //GET Data
        var body =  JSON.parse(event.body); 
        
    const poolData={
      UserPoolId: 'eu-west-2_W4Gdcok54', // Your user pool id here
      ClientId: '54klbd89520q5j68fe8hefml1f', // Your client id here
    };
        var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);// user pool 
        const getUser=()=>{
            return new AmazonCognitoIdentity.CognitoUser({
                Username:body.email,// user email
                Pool:userPool // pool data
            })
        }
        var password = body.password
        var code = body.code

        
    new Promise((resolve, reject) => {        
        // password reset function 
        getUser().confirmPassword(code,password,{
        
            
            onSuccess:(data)=>{
                console.log("onSuccess:", data);
                callback(null,{ 
                    statusCode: 200,                
                    headers: {
                      "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
                      'Content-Type': 'application/json',
                    }, 
                    body:"Password Changed" 
                })
            },
            onFailure:(err)=>{
                
       callback(null,{
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
          }
        });
                      reject(err);

            }
        })
    });
    }
    
}               