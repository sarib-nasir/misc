var config =  require ('../../config.js');

module.exports = {

 
//======================================================================
// GET user accounts by account ID
//======================================================================


get_user_accounts_by_account_id : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  //Path Parameters (ab.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (ab.com?title='sdad'&per_page=10&page=1&page=1&sort=ASC)
  //JSON (queryStringParam.title)
  const queryStringParam = event.queryStringParameters;
  //GET Data
 //var body = JSON.parse(event.body);  
  
  var title = ((queryStringParam && queryStringParam.title)?queryStringParam.title:'');
  var per_page = ((queryStringParam && queryStringParam.per_page <=50)? JSON.parse(JSON.parse(JSON.stringify(queryStringParam.per_page))):50);
  var page =  ((queryStringParam && queryStringParam.page)?queryStringParam.page:0);
  var account_type =  ((queryStringParam && queryStringParam.account_type)?queryStringParam.account_type:'');
  var sort =  ((queryStringParam && queryStringParam.sort)? JSON.parse(JSON.parse(JSON.stringify(queryStringParam.sort))) :{created_at: -1,full_name:1});
  
    var account_id =  ((pathParam && pathParam.accountID)?pathParam.accountID:null);
    //var user_id =  "62767aa4-711b-4cfa-9a34-66a9cf853f79";

  //User ID Required
  if(!account_id){
    callback(null,{
        "statusCode": 500,
        "body": JSON.stringify("User ID parameter does not exist in body."),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      });
  }
  
  
  await config.connectToDatabase()
    .then(db => config.get_user_accounts_by_account_id(db,account_id,title,page,per_page,account_type,sort))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
    
};