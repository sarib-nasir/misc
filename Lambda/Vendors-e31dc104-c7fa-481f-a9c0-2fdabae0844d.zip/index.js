"use strict";
//vendors
const get_vendors = require("./vendors/get_items.js");
const add_vendors = require("./vendors/add_item.js");
const update_vendors = require("./vendors/update_item.js");
const delete_vendors = require("./vendors/delete_item.js");



exports.handler =  async (event, context, callback) => {

//Get Item:Default
if(event.httpMethod=="GET"){
   
   if(event.pathParameters && event.pathParameters.vendor_id){
         await get_vendors.get_item(event, context, callback);
   }else{
         await get_vendors.get_items(event, context, callback);
   }
}     
     
//Add Item:Default
if(event.httpMethod=="POST"){
   await add_vendors.add_item(event, context, callback);
}

//Update Item:Default
if(event.httpMethod=="PUT"){
   await update_vendors.update_item(event, context, callback);
}
  
//Delete:Default
if(event.httpMethod=="DELETE"){
   await delete_vendors.delete_item(event, context, callback);
}



};