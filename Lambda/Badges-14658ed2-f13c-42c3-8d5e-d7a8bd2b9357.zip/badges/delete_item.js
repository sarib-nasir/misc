var ObjectId = require('mongodb').ObjectID;

var config =  require ('../config.js');

module.exports = {

//======================================================================
// Delete Item
//======================================================================

delete_item : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  
   //Path Parameters (wheatpaste.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (wheatpaste.com?title='sdad')
  //JSON (queryStringParam.title)
  const queryStringParam = event.queryStringParameters;  
  
  //GET Data
  var badge_id = pathParam.badge_id; 
  
  console.log(badge_id)
  await config.connectToDatabase()
    .then(db => config.delete_doc(db,badge_id))
    .then(result => {
      console.log("delete result here")
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
   


 
    
}