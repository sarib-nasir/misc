"use strict";
//badges
const get_badges = require("./badges/get_items.js");
const add_badges = require("./badges/add_item.js");
const update_badges = require("./badges/update_item.js");
const delete_badges = require("./badges/delete_item.js");



exports.handler =  async (event, context, callback) => {

//Get Item:Default
if(event.httpMethod=="GET"){
   
   if(event.pathParameters && event.pathParameters.badge_id){
         await get_badges.get_item(event, context, callback);
   }else{
         await get_badges.get_items(event, context, callback);
   }
}     
     
//Add Item:Default
if(event.httpMethod=="POST"){
   await add_badges.add_item(event, context, callback);
}

//Update Item:Default
if(event.httpMethod=="PUT"){
   await update_badges.update_item(event, context, callback);
}
  
//Delete:Default
if(event.httpMethod=="DELETE"){
   await delete_badges.delete_item(event, context, callback);
}



};