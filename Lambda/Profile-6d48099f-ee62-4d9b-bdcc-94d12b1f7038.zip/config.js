const MongoClient = require('mongodb').MongoClient;
var ObjectId = require('mongodb').ObjectId;
// const {ObjectId} = require('mongodb');
/**
* This file is use to handle all the functions
* in your development cycle save you a lot of time by preventing you having to rewrite<br>
* major documentation parts to generate some usable form of documentation.
*/
module.exports = {

//======================================================================
// MongoDB Auth Url with username, pasword and database
//======================================================================
  mongo_url: function() {
    return "mongodb+srv://sarib:sarib123@test.r5zoc.mongodb.net/LambdaTest?retryWrites=true&w=majority";
  },
  
//======================================================================
// Database Name
//======================================================================
  dbname: function() {
    return "LambdaTest";
  },
  
//======================================================================
// Collection  Name
//======================================================================
  collection_name: function() {
    return "Profile";
  },
//======================================================================
// AWS Region
//======================================================================
  region: function() {
    return "eu-west-2";
  },
//======================================================================
// S3 Bucket Name
//======================================================================
  bucket_name: function() {
    return "wheatpaste-production";
  },
//======================================================================
// S3 Bucket URL
//======================================================================
  bucket_url: function(uid) {
    return "media-archive/media-library/" + uid;
  },
//======================================================================
// MongoDB Database Function
//======================================================================
  connectToDatabase: function() {
    return MongoClient.connect(this.mongo_url(), {
      useNewUrlParser: true,
      useUnifiedTopology: true
    }).then(client => {
      // The database name is part of the url.  client.db() seems 
      // to know that and works even without a parameter that 
      // relays the db name.
      let db = client.db(this.dbname());
      return db;
      // client.close() if you want to
    }).catch(err => console.log(err));
  },
//======================================================================
// Insert Data
//======================================================================
  insert_doc: function(db, items_bucket) {
    console.log('=> query database');
    return db.collection(this.collection_name()).insertOne(items_bucket).then((items) => {
      //console.log(items);
      return {
        "statusCode": 200,
        "body": JSON.stringify(items),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
//======================================================================
// Update Data
//======================================================================
  update_doc: function(db,profile_id, items_bucket) {
    console.log('=> update query database');
    console.log("update DB querying  :"+profile_id)
    return db.collection(this.collection_name()).findOneAndUpdate({
      _id: ObjectId(profile_id),

    }, {
      $set: items_bucket
    }, {
      returnOriginal: false, upsert: true
    }).then((items) => {
      return {
        "statusCode": 200,
        "body": JSON.stringify(items),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
//======================================================================
// Delete Data
//======================================================================
  delete_doc: function(db,profile_id) {

    console.log('=> query database');
    console.log("delete DB querying  :"+profile_id)
    return db.collection(this.collection_name()).deleteOne({
        _id:  ObjectId(profile_id),

    }).then((items) => {
      return {
        "statusCode": 200,
        "body": JSON.stringify(items),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },

//======================================================================
// Get All List with Pagination
//======================================================================
    get_items : function (db,name,page,per_page,sort) {
    


    return db.collection(this.collection_name()).aggregate([
  {
    $facet: {
      metadatax: [
        {
          $match: {
            name: {$regex : ".*"+name+".*"},
          }
          
        },
        {
           $sort: sort
           
         },     
        {
          $count: "total_records",
          
        }
      ],
      metadata: [
        {
          $match: {
            name: {$regex : ".*"+name+".*"},
          }
        },
         {
           $sort: sort
           
         },
        {
          $skip: page * per_page
        },
        {
          $limit: per_page
        },
        {
          $group: {
            _id: "",
            count: {
              $sum: 1
            },
            data: {
              $push: "$$ROOT"
            }
          }
        }
      ]
    }
  },
  {
    $unwind: "$metadata"
  },
  {
    $project: {
      data: "$metadata.data",
      metadata: {
        $mergeObjects: [
          {
            per_page: "$metadata.count",
            total_pages: { $ceil: { $divide: [ { $arrayElemAt: [ "$metadatax.total_records",  0 ] } , per_page ] } } 
          },
          {
            $arrayElemAt: [
              "$metadatax",
              0
            ]
          },
          
        ]
      }
    }
  }
]).toArray()
    .then((items) => {       
      return {
        "statusCode": 200,
        "body": JSON.stringify(items[0]),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      }; 
      
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });


},
//======================================================================
// Get Item
//======================================================================
  get_item: function(db,profile_id) {
    console.log("get DB querying  :"+profile_id)
    return db.collection(this.collection_name()).findOne({
      "_id": ObjectId(profile_id),
    }).then((items) => {
      return {
        "statusCode": 200,
        "body": JSON.stringify(items),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    }).catch(err => {
      console.log('=> an error occurred: ', err);
      return {
        "statusCode": 500,
        "body": JSON.stringify(err),
        "headers": {
            "Access-Control-Allow-Origin": "*"
        }
      };
    });
  },
};