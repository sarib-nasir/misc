const MongoClient = require('mongodb').MongoClient;
var config =  require ('../config.js');
var ObjectId = require('mongodb').ObjectID;

module.exports = {

//======================================================================
// Update Item
//======================================================================

update_item : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;

  //Path Parameters (wheatpaste.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (wheatpaste.com?name='sdad')
  //JSON (queryStringParam.name)
  const queryStringParam = event.queryStringParameters;
  
  //GET Data
  var body = JSON.parse(event.body); 
  var profile_id = pathParam.profile_id;   


  var items_bucket =  {
        name : body.name,
        updated_at: new Date(),
    
  };
  console.log(profile_id)
  await config.connectToDatabase()
    .then(db => config.update_doc(db,profile_id,items_bucket))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
   

 
    
}