var config =  require ('../config.js');

module.exports = {
  
//======================================================================
// GET All Items
//======================================================================


get_items : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  //Path Parameters (wheatpaste.com/accountID/)
  //JSON (pathParam.accountID)
  //const pathParam = event.pathParameters;
  
  //Query String Parameters (wheatpaste.com?name='sdad'&per_page=10&page=1&page=1&sort=ASC)
  //JSON (queryStringParam.name)
  const queryStringParam = event.queryStringParameters;
  //GET Data
 // var body = JSON.parse(event.body);  
 
 
  var name = ((queryStringParam && queryStringParam.name)?queryStringParam.name:'');
  var per_page = ((queryStringParam && queryStringParam.per_page <=50)? JSON.parse(JSON.parse(JSON.stringify(queryStringParam.per_page))):50);
  var page =  ((queryStringParam && queryStringParam.page)?queryStringParam.page:0);
  var sort =  ((queryStringParam && queryStringParam.sort)? JSON.parse(JSON.parse(JSON.stringify(queryStringParam.sort))) :{created_at: -1,name:1});
  
  await config.connectToDatabase()
    .then(db => config.get_items(db,name,page,per_page,sort))
    .then(result => {
      console.log("-----------result--------");
      console.log(result);
      console.log(result.body);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
   

//======================================================================
// GET Single Item
//======================================================================
get_item : async function (event, context, callback){
  context.callbackWaitsForEmptyEventLoop = false;
  
  //Path Parameters (wheatpaste.com/accountID/)
  //JSON (pathParam.accountID)
  const pathParam = event.pathParameters;
  
  //Query String Parameters (wheatpaste.com?name='sdad'&per_page=10&page=1&page=1&sort=ASC)
  //JSON (queryStringParam.name)
  const queryStringParam = event.queryStringParameters;
  //GET Data
 // var body = JSON.parse(event.body);    
  var profile_id = pathParam.profile_id; 

  console.log(profile_id)
  await config.connectToDatabase()
    .then(db => config.get_item(db,profile_id))
    .then(result => {
      console.log(result);
      callback(null, result);
    })
    .catch(err => {
      console.log('=> an error occurred: ', err);
      callback(err);
    });
                  
},
 
    
};