"use strict";
//profile
const get_profile = require("./profile/get_items.js");
const add_profile = require("./profile/add_item.js");
const update_profile = require("./profile/update_item.js");
const delete_profile = require("./profile/delete_item.js");



exports.handler =  async (event, context, callback) => {

//Get Item:Default
if(event.httpMethod=="GET"){
   
   if(event.pathParameters && event.pathParameters.profile_id){
         await get_profile.get_item(event, context, callback);
   }else{
         await get_profile.get_items(event, context, callback);
   }
}     
     
//Add Item:Default
if(event.httpMethod=="POST"){
   await add_profile.add_item(event, context, callback);
}

//Update Item:Default
if(event.httpMethod=="PUT"){
   await update_profile.update_item(event, context, callback);
}
  
//Delete:Default
if(event.httpMethod=="DELETE"){
   await delete_profile.delete_item(event, context, callback);
}



};